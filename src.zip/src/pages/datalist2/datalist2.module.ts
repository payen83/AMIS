import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Datalist2Page } from './datalist2';

@NgModule({
  declarations: [
    Datalist2Page,
  ],
  imports: [
    IonicPageModule.forChild(Datalist2Page),
  ],
})
export class Datalist2PageModule {}
