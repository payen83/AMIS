import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Camera2Page } from './camera2';

@NgModule({
  declarations: [
    Camera2Page,
  ],
  imports: [
    IonicPageModule.forChild(Camera2Page),
  ],
})
export class Camera2PageModule {}
